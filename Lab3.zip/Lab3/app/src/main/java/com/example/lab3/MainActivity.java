package com.example.lab3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    HttpURLConnection conn = null;
    EditText locationInput;
    TextView locationText;
    TextView weatherText;
    Button submitButton;
    Button submitLatLonButton; // submits immediately based on the latitude and longitude
    Location location;
    LocationManager lm;
    double longitude = 0.0;
    double latitude = 0.0;

    private final LocationListener locationListener = new LocationListener() {
        public void onLocationChanged(Location location) {
            longitude = location.getLongitude();
            latitude = location.getLatitude();
        }
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationInput = (EditText) findViewById(R.id.cityNameInput);
        locationText = (TextView) findViewById(R.id.locationText);
        weatherText = (TextView) findViewById(R.id.weatherText);
        submitButton = (Button) findViewById(R.id.submitButton);
        submitLatLonButton = (Button) findViewById(R.id.weatherFromCoordsButton);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1); // get GPS permissions
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 10, locationListener);

        submitButton.setOnClickListener(view -> {
            JSONTask myTask = new JSONTask();
            myTask.execute("http://api.openweathermap.org/data/2.5/weather?q=" + locationInput.getText() + "&APPID=fa9669c766dec51c552f613f7b537248");
        });

        submitLatLonButton.setOnClickListener(view -> {
            JSONTask myTask = new JSONTask();
            myTask.execute("http://api.openweathermap.org/data/2.5/weather?lat=" + latitude + "&lon="+ longitude + "&appid=fa9669c766dec51c552f613f7b537248");
        });
    }

    class JSONTask extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(strings[0]);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(5000); //5 sec.
                conn.connect();
                if (conn.getResponseCode()== HttpURLConnection.HTTP_OK){
                    InputStream stream = conn.getInputStream();
                    BufferedReader reader = new BufferedReader( new InputStreamReader(stream));
                    StringBuffer buffer = new StringBuffer();
                    String line= "";
                    while((line = reader.readLine()) != null){
                        buffer.append(line);
                    }
                    return buffer.toString();
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
                return null;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }finally {
                conn.disconnect();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            try {
                String jsonString = result.toString();
                JSONObject jsonObject = new JSONObject(jsonString);
                JSONObject firstObj = jsonObject.getJSONObject("main");
                float weather = Float.parseFloat(firstObj.getString("temp"));
                String locationName = jsonObject.getString("name");
                String conditions = jsonObject.getJSONArray("weather").getJSONObject(0).getString("main");
                weather -= 273.15; // converts to celsius
                locationText.setText("Location: " + locationName);
                weatherText.setText("Temperature: " + String.format("%.0f", weather) + "°C. \nWeather is described as " + conditions + ".");
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                locationText.setText("Invalid location.");
                weatherText.setText("");
            }
        }
    }

}